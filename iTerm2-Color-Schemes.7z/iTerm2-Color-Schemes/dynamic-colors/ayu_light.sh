#!/bin/sh
# ayu_light
printf "\033]4;0;#000000;1;#ff3333;2;#86b300;3;#f29718;4;#41a6d9;5;#f07178;6;#4dbf99;7;#ffffff;8;#323232;9;#ff6565;10;#b8e532;11;#ffc94a;12;#73d8ff;13;#ffa3aa;14;#7ff1cb;15;#ffffff\007"
printf "\033]10;#5c6773;#fafafa;#ff6a00\007"
printf "\033]17;#f0eee4\007"
printf "\033]19;#5c6773\007"
printf "\033]5;0;#5c6773\007"
