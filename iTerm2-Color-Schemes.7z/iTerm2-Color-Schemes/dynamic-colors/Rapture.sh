#!/bin/sh
# Rapture
printf "\033]4;0;#000000;1;#fc644d;2;#7afde1;3;#fff09b;4;#6c9bf5;5;#ff4fa1;6;#64e0ff;7;#c0c9e5;8;#304b66;9;#fc644d;10;#7afde1;11;#fff09b;12;#6c9bf5;13;#ff4fa1;14;#64e0ff;15;#ffffff\007"
printf "\033]10;#c0c9e5;#111e2a;#ffffff\007"
printf "\033]17;#304b66\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#d5ced9\007"
