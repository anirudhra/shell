#!/bin/sh
# Popping and Locking
printf "\033]4;0;#1d2021;1;#cc241d;2;#98971a;3;#d79921;4;#458588;5;#b16286;6;#689d6a;7;#a89984;8;#928374;9;#f42c3e;10;#b8bb26;11;#fabd2f;12;#99c6ca;13;#d3869b;14;#7ec16e;15;#ebdbb2\007"
printf "\033]10;#ebdbb2;#181921;#c7c7c7\007"
printf "\033]17;#ebdbb2\007"
printf "\033]19;#928374\007"
printf "\033]5;0;#ffffff\007"
