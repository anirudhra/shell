#!/bin/sh
# WarmNeon
printf "\033]4;0;#000000;1;#e24346;2;#39b13a;3;#dae145;4;#4261c5;5;#f920fb;6;#2abbd4;7;#d0b8a3;8;#fefcfc;9;#e97071;10;#9cc090;11;#ddda7a;12;#7b91d6;13;#f674ba;14;#5ed1e5;15;#d8c8bb\007"
printf "\033]10;#afdab6;#404040;#30ff24\007"
printf "\033]17;#b0ad21\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#22ff0c\007"
