#!/bin/sh
# Wombat
printf "\033]4;0;#000000;1;#ff615a;2;#b1e969;3;#ebd99c;4;#5da9f6;5;#e86aff;6;#82fff7;7;#dedacf;8;#313131;9;#f58c80;10;#ddf88f;11;#eee5b2;12;#a5c7ff;13;#ddaaff;14;#b7fff9;15;#ffffff\007"
printf "\033]10;#dedacf;#171717;#bbbbbb\007"
printf "\033]17;#453b39\007"
printf "\033]19;#b6bbc0\007"
printf "\033]5;0;#ffffff\007"
