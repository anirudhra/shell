#!/bin/sh
# Parasio Dark
printf "\033]4;0;#2f1e2e;1;#ef6155;2;#48b685;3;#fec418;4;#06b6ef;5;#815ba4;6;#5bc4bf;7;#a39e9b;8;#776e71;9;#ef6155;10;#48b685;11;#fec418;12;#06b6ef;13;#815ba4;14;#5bc4bf;15;#e7e9db\007"
printf "\033]10;#a39e9b;#2f1e2e;#a39e9b\007"
printf "\033]17;#4f424c\007"
printf "\033]19;#a39e9b\007"
printf "\033]5;0;#a39e9b\007"
