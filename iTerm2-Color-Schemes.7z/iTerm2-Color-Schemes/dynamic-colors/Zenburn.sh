#!/bin/sh
# Zenburn
printf "\033]4;0;#4d4d4d;1;#705050;2;#60b48a;3;#f0dfaf;4;#506070;5;#dc8cc3;6;#8cd0d3;7;#dcdccc;8;#709080;9;#dca3a3;10;#c3bf9f;11;#e0cf9f;12;#94bff3;13;#ec93d3;14;#93e0e3;15;#ffffff\007"
printf "\033]10;#dcdccc;#3f3f3f;#73635a\007"
printf "\033]17;#21322f\007"
printf "\033]19;#c2d87a\007"
printf "\033]5;0;#dcdccc\007"
