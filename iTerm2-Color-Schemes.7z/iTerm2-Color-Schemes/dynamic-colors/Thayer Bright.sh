#!/bin/sh
# Thayer Bright
printf "\033]4;0;#1b1d1e;1;#f92672;2;#4df840;3;#f4fd22;4;#2757d6;5;#8c54fe;6;#38c8b5;7;#ccccc6;8;#505354;9;#ff5995;10;#b6e354;11;#feed6c;12;#3f78ff;13;#9e6ffe;14;#23cfd5;15;#f8f8f2\007"
printf "\033]10;#f8f8f8;#1b1d1e;#fc971f\007"
printf "\033]17;#4d4d4d\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
