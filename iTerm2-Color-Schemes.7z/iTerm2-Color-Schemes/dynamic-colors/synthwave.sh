#!/bin/sh
# synthwave
printf "\033]4;0;#000000;1;#f6188f;2;#1ebb2b;3;#fdf834;4;#2186ec;5;#f85a21;6;#12c3e2;7;#ffffff;8;#000000;9;#f841a0;10;#25c141;11;#fdf454;12;#2f9ded;13;#f97137;14;#19cde6;15;#ffffff\007"
printf "\033]10;#dad9c7;#000000;#19cde6\007"
printf "\033]17;#19cde6\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#dad9c7\007"
