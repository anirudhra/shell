#!/bin/sh
# midnight-in-mojave
printf "\033]4;0;#1e1e1e;1;#ff453a;2;#32d74b;3;#ffd60a;4;#0a84ff;5;#bf5af2;6;#5ac8fa;7;#ffffff;8;#1e1e1e;9;#ff453a;10;#32d74b;11;#ffd60a;12;#0a84ff;13;#bf5af2;14;#5ac8fa;15;#ffffff\007"
printf "\033]10;#ffffff;#1e1e1e;#32d74b\007"
printf "\033]17;#4a504d\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
