#!/bin/sh
# FishTank
printf "\033]4;0;#03073c;1;#c6004a;2;#acf157;3;#fecd5e;4;#525fb8;5;#986f82;6;#968763;7;#ecf0fc;8;#6c5b30;9;#da4b8a;10;#dbffa9;11;#fee6a9;12;#b2befa;13;#fda5cd;14;#a5bd86;15;#f6ffec\007"
printf "\033]10;#ecf0fe;#232537;#fecd5e\007"
printf "\033]17;#fcf7e9\007"
printf "\033]19;#232537\007"
printf "\033]5;0;#f6ffeb\007"
