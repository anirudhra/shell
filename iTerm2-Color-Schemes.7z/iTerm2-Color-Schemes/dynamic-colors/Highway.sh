#!/bin/sh
# Highway
printf "\033]4;0;#000000;1;#d00e18;2;#138034;3;#ffcb3e;4;#006bb3;5;#6b2775;6;#384564;7;#ededed;8;#5d504a;9;#f07e18;10;#b1d130;11;#fff120;12;#4fc2fd;13;#de0071;14;#5d504a;15;#ffffff\007"
printf "\033]10;#ededed;#222225;#e0d9b9\007"
printf "\033]17;#384564\007"
printf "\033]19;#ededed\007"
printf "\033]5;0;#fff8d8\007"
