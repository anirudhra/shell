#!/bin/sh
# DjangoSmooth
printf "\033]4;0;#000000;1;#fd6209;2;#41a83e;3;#ffe862;4;#989898;5;#f8f8f8;6;#9df39f;7;#e8e8e7;8;#323232;9;#ff943b;10;#73da70;11;#ffff94;12;#cacaca;13;#ffffff;14;#cfffd1;15;#ffffff\007"
printf "\033]10;#f8f8f8;#245032;#336442\007"
printf "\033]17;#336442\007"
printf "\033]19;#f8f8f8\007"
printf "\033]5;0;#f8f8f8\007"
