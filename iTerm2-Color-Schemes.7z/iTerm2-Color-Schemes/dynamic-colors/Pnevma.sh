#!/bin/sh
# Pnevma
printf "\033]4;0;#2f2e2d;1;#a36666;2;#90a57d;3;#d7af87;4;#7fa5bd;5;#c79ec4;6;#8adbb4;7;#d0d0d0;8;#4a4845;9;#d78787;10;#afbea2;11;#e4c9af;12;#a1bdce;13;#d7beda;14;#b1e7dd;15;#efefef\007"
printf "\033]10;#d0d0d0;#1c1c1c;#e4c9af\007"
printf "\033]17;#4d4d4d\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#e5e5e5\007"
