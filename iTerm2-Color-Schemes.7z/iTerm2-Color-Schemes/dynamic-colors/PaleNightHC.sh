#!/bin/sh
# PaleNightHC
printf "\033]4;0;#000000;1;#f07178;2;#c3e88d;3;#ffcb6b;4;#82aaff;5;#c792ea;6;#89ddff;7;#ffffff;8;#666666;9;#f6a9ae;10;#dbf1ba;11;#ffdfa6;12;#b4ccff;13;#ddbdf2;14;#b8eaff;15;#999999\007"
printf "\033]10;#cccccc;#3e4251;#ffcb6b\007"
printf "\033]17;#717cb4\007"
printf "\033]19;#80cbc4\007"
printf "\033]5;0;#ffffff\007"
