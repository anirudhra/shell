#!/bin/sh
# Darkside
printf "\033]4;0;#000000;1;#e8341c;2;#68c256;3;#f2d42c;4;#1c98e8;5;#8e69c9;6;#1c98e8;7;#bababa;8;#000000;9;#e05a4f;10;#77b869;11;#efd64b;12;#387cd3;13;#957bbe;14;#3d97e2;15;#bababa\007"
printf "\033]10;#bababa;#222324;#bbbbbb\007"
printf "\033]17;#303333\007"
printf "\033]19;#bababa\007"
printf "\033]5;0;#ffffff\007"
