#!/bin/sh
# Flatland
printf "\033]4;0;#1d1d19;1;#f18339;2;#9fd364;3;#f4ef6d;4;#5096be;5;#695abc;6;#d63865;7;#ffffff;8;#1d1d19;9;#d22a24;10;#a7d42c;11;#ff8949;12;#61b9d0;13;#695abc;14;#d63865;15;#ffffff\007"
printf "\033]10;#b8dbef;#1d1f21;#708284\007"
printf "\033]17;#2b2a24\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
