#!/bin/sh
# Symfonic
printf "\033]4;0;#000000;1;#dc322f;2;#56db3a;3;#ff8400;4;#0084d4;5;#b729d9;6;#ccccff;7;#ffffff;8;#1b1d21;9;#dc322f;10;#56db3a;11;#ff8400;12;#0084d4;13;#b729d9;14;#ccccff;15;#ffffff\007"
printf "\033]10;#ffffff;#000000;#dc322f\007"
printf "\033]17;#073642\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ff8400\007"
