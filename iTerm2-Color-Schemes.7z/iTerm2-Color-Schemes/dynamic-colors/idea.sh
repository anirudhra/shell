#!/bin/sh
# idea
printf "\033]4;0;#adadad;1;#fc5256;2;#98b61c;3;#ccb444;4;#437ee7;5;#9d74b0;6;#248887;7;#181818;8;#ffffff;9;#fc7072;10;#98b61c;11;#ffff0b;12;#6c9ced;13;#fc7eff;14;#248887;15;#181818\007"
printf "\033]10;#adadad;#202020;#bbbbbb\007"
printf "\033]17;#44475a\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#e6e6e6\007"
