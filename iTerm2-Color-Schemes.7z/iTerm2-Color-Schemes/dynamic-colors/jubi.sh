#!/bin/sh
# jubi
printf "\033]4;0;#3b3750;1;#cf7b98;2;#90a94b;3;#6ebfc0;4;#576ea6;5;#bc4f68;6;#75a7d2;7;#c3d3de;8;#a874ce;9;#de90ab;10;#bcdd61;11;#87e9ea;12;#8c9fcd;13;#e16c87;14;#b7c9ef;15;#d5e5f1\007"
printf "\033]10;#c3d3de;#262b33;#c3d3de\007"
printf "\033]17;#5b5184\007"
printf "\033]19;#1e1b2e\007"
printf "\033]5;0;#a874ce\007"
