#!/bin/sh
# Konsolas
printf "\033]4;0;#000000;1;#aa1717;2;#18b218;3;#ebae1f;4;#2323a5;5;#ad1edc;6;#42b0c8;7;#c8c1c1;8;#7b716e;9;#ff4141;10;#5fff5f;11;#ffff55;12;#4b4bff;13;#ff54ff;14;#69ffff;15;#ffffff\007"
printf "\033]10;#c8c1c1;#060606;#c8c1c1\007"
printf "\033]17;#060606\007"
printf "\033]19;#c8c1c1\007"
printf "\033]5;0;#c8c1c1\007"
