#!/bin/sh
# BlulocoLight
printf "\033]4;0;#cbccd5;1;#c90e42;2;#21883a;3;#d54d17;4;#1e44dd;5;#6d1bed;6;#1f4d7a;7;#000000;8;#dedfe8;9;#fc4a6d;10;#34b354;11;#b89427;12;#1085d9;13;#c00db3;14;#5b80ad;15;#1d1d22\007"
printf "\033]10;#2a2c33;#f7f7f7;#ed0047\007"
printf "\033]17;#d2ecff\007"
printf "\033]19;#2a2c33\007"
printf "\033]5;0;#2a2c33\007"
