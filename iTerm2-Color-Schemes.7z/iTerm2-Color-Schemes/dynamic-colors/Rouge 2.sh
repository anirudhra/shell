#!/bin/sh
# Rouge 2
printf "\033]4;0;#5d5d6b;1;#c6797e;2;#969e92;3;#dbcdab;4;#6e94b9;5;#4c4e78;6;#8ab6c1;7;#e8e8ea;8;#616274;9;#c6797e;10;#e6dcc4;11;#e6dcc4;12;#98b3cd;13;#8283a1;14;#abcbd3;15;#e8e8ea\007"
printf "\033]10;#a2a3aa;#17182b;#969e92\007"
printf "\033]17;#5d5d6b\007"
printf "\033]19;#dfe5ee\007"
printf "\033]5;0;#6e94b9\007"
