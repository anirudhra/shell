#!/bin/sh
# Rippedcasts
printf "\033]4;0;#000000;1;#cdaf95;2;#a8ff60;3;#bfbb1f;4;#75a5b0;5;#ff73fd;6;#5a647e;7;#bfbfbf;8;#666666;9;#eecbad;10;#bcee68;11;#e5e500;12;#86bdc9;13;#e500e5;14;#8c9bc4;15;#e5e5e5\007"
printf "\033]10;#ffffff;#2b2b2b;#7f7f7f\007"
printf "\033]17;#5a647e\007"
printf "\033]19;#f2f2f2\007"
printf "\033]5;0;#d0f367\007"
