#!/bin/sh
# Brogrammer
printf "\033]4;0;#1f1f1f;1;#f81118;2;#2dc55e;3;#ecba0f;4;#2a84d2;5;#4e5ab7;6;#1081d6;7;#d6dbe5;8;#d6dbe5;9;#de352e;10;#1dd361;11;#f3bd09;12;#1081d6;13;#5350b9;14;#0f7ddb;15;#ffffff\007"
printf "\033]10;#d6dbe5;#131313;#b9b9b9\007"
printf "\033]17;#1f1f1f\007"
printf "\033]19;#d6dbe5\007"
printf "\033]5;0;#d6dbe5\007"
