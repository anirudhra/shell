#!/bin/sh
# deep
printf "\033]4;0;#000000;1;#d70005;2;#1cd915;3;#d9bd26;4;#5665ff;5;#b052da;6;#50d2da;7;#e0e0e0;8;#535353;9;#fb0007;10;#22ff18;11;#fedc2b;12;#9fa9ff;13;#e09aff;14;#8df9ff;15;#ffffff\007"
printf "\033]10;#cdcdcd;#090909;#d0d0d0\007"
printf "\033]17;#780002\007"
printf "\033]19;#ececec\007"
printf "\033]5;0;#ffffff\007"
