#!/usr/bin/env bash

sudo cp ./*.xml /usr/share/gtksourceview-3.0/styles
